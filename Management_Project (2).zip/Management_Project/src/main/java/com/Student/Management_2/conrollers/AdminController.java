package com.Student.Management_2.conrollers;

public class AdminController {
	
}
